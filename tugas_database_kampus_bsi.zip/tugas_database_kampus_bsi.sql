-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 31, 2018 at 08:29 PM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 7.2.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tugas_database_kampus_bsi`
--

-- --------------------------------------------------------

--
-- Table structure for table `dosen`
--

CREATE TABLE `dosen` (
  `ID_Dosen` char(10) NOT NULL,
  `Nama_Dosen` varchar(50) NOT NULL,
  `Mata_Kuliah` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dosen`
--

INSERT INTO `dosen` (`ID_Dosen`, `Nama_Dosen`, `Mata_Kuliah`) VALUES
('RTK', 'Ratna Kartika Sari', 'BAHASA INGGRIS II'),
('HYR', 'Hafdiarsya Saiyar ', 'STRUKTUR DATA'),
('AEQ', 'Ade Priyatna  ', 'APLIKASI BASIS DATA'),
('DHE', 'Adi Chandra Setiawan  ', 'WEB PROGRAMMING I'),
('HZH', 'Hamim Sazadah  ', 'SISTEM BASIS DATA');

-- --------------------------------------------------------

--
-- Table structure for table `mahasiswa`
--

CREATE TABLE `mahasiswa` (
  `NIM` char(8) NOT NULL,
  `Nama_Mahasiswa` varchar(50) NOT NULL,
  `Kelas` varchar(10) NOT NULL,
  `Tempat_Tgl_Lahir` varchar(50) NOT NULL,
  `Alamat` varchar(100) NOT NULL,
  `Jenis_Kelamin` enum('Laki-Laki','Perempuan') NOT NULL,
  `Status` enum('Aktif','Tidak Aktif') NOT NULL DEFAULT 'Aktif'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mahasiswa`
--

INSERT INTO `mahasiswa` (`NIM`, `Nama_Mahasiswa`, `Kelas`, `Tempat_Tgl_Lahir`, `Alamat`, `Jenis_Kelamin`, `Status`) VALUES
('12170731', 'Rendi Simon Lesmana', '12.2D.07', 'Jakarta,3 Juli 1998', 'Jl. Rawamangun Muka 90', 'Laki-Laki', 'Aktif'),
('12170383', 'Maulana Yusuf', '12.2D.07', 'Jakarta,14 Februari 1997', 'Jl. Bendungan Hilir 20', 'Laki-Laki', 'Aktif'),
('12171093', 'Zheyka Prahudi Vianto', '12.2D.07', 'Jayapura, 19 Desember 1996', 'Jl. Kayu Putih No. 30', 'Laki-Laki', 'Aktif'),
('12170957', 'Jhordian', '12.2D.07', 'Jakarta, 28 Januari 1989', 'Jl. Landasan Pacu Utara 99', 'Laki-Laki', 'Aktif'),
('12170281', 'Bima Firliansyah', '12.2D.07', 'Jakarta, 9 Juli 1991', 'Jl. Sumur Batu Raya 30', 'Laki-Laki', 'Aktif');

-- --------------------------------------------------------

--
-- Table structure for table `mata_kuliah`
--

CREATE TABLE `mata_kuliah` (
  `Kode_MK` char(4) NOT NULL,
  `Nama_MK` varchar(50) NOT NULL,
  `SKS` varchar(50) NOT NULL,
  `Hari` varchar(50) NOT NULL,
  `Ruang` varchar(50) NOT NULL,
  `Waktu` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mata_kuliah`
--

INSERT INTO `mata_kuliah` (`Kode_MK`, `Nama_MK`, `SKS`, `Hari`, `Ruang`, `Waktu`) VALUES
('105', 'BAHASA INGGRIS II ', '2', 'Kamis', '306', '18:30-20:00'),
('694', 'APLIKASI BASIS DATA ', '3', 'Jum\'at', '401', '19:15-21:15'),
('310', 'STRUKTUR DATA', '3', 'Rabu', '202', '17:00-19:15 '),
('726', 'WEB PROGRAMMING I ', '4', 'Senin', '402', ' 18:30-21:15  	'),
('360', 'SISTEM BASIS DATA  ', '3', 'Selasa', '403', '19:15-21:15 ');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `dosen`
--
ALTER TABLE `dosen`
  ADD PRIMARY KEY (`ID_Dosen`);

--
-- Indexes for table `mahasiswa`
--
ALTER TABLE `mahasiswa`
  ADD PRIMARY KEY (`NIM`);

--
-- Indexes for table `mata_kuliah`
--
ALTER TABLE `mata_kuliah`
  ADD PRIMARY KEY (`Kode_MK`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
